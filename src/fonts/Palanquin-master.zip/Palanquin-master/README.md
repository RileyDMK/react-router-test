# Palanquin Fonts

Palanquin is a Unicode-compliant Latin and Devanagari text type family designed for the digital age. 
The Devanagari is monolinear and was designed alongside the sans serif Latin.

Palanquin Dark is the heavier display family, with 4 weights. Palanquin is a text family with seven text weights. 
The Palanquin superfamily is versatile and strikes a balance between typographic conventions and that bit of sparkle.

Many thanks to Michael for all the technical assistance. Heartfelt thanks to Maggi for the sincere support.

The Palanquin project is led by Pria Ravichandran, a type designer from India. 
To contribute, see [github.com/VanillaandCream/Palanquin](https://github.com/VanillaandCream/Palanquin)